$(document).ready(function(){
    // UX behavior
    $.ajax(
        "tabs.html",{
            success: function(response){
                $("#tabs").append(response)
            },
            async:false
        }
    )
    $("#tabs").tabs();
    $("#tabs li").click(function(){
        history.pushState("","","index.html")
        $(".toggle+div").hide()
    })
    $("body").on("click",".toggle",function(){
        $(".toggle+div").css("border","none")
        $(this).next().slideToggle("slow",function(){
            $(this).css({"border":"1px solid gray","border-radius":"3px"})
        })
        $(".toggle").not($(this)).next().hide("normal")
    })
    // load articles list
    articles = []
    $.ajax(
        "articles/",
        {
            success:function(response){
                lis = $("<iframe>").append($.parseHTML(response)).find("ul li a")
                lis = $(lis).toArray()
                lis.shift()
                $.each($(lis),function(i,e){
                    articles.push($(e).attr("href"))
                })
            },
            async:false
        }
    )
    // rendering articles
    $("body").on("click",".article",function(){render($(this).data("number"))})
    function render(number){
        $.ajax(
            "articles/"+number+".html",
            {
                success:function(response){
                    $("#results").html("<div class=\"number\"><span>"+number+"</span><span class=\"material-symbols-outlined\">content_copy</span></div>"+response)
                },
                error:function(){
                    $("#results").html("no results found, or article does not exist")
                }
            }
        )
        $("#tabs li:not(:visible) a").click()        
    }
    // article search
    function process_query(keyword){
        has_star_format = /^\*\d{5}$/.test(keyword)
        if(has_star_format){
            render(keyword)
        }
        else{
            suggests = lookup_articles(keyword)
            suggests.sort(function(a,b){return (a[2]>b[2]) ? -1 : 1})
            suggests = suggests.filter(function(e){return e[2]!==0})
            suggests = $.map(suggests,function(e){
                return "<li class=\"article\" data-number=\""+e[0]+"\">"+e[1]+"</li>"
            })
            $("#results").html(suggests.join(""))
            $("#tabs li:not(:visible) a").click()        
        }
    }
    $("#search input").keyup(function(k){
        keyword = $(this).val()
        if(keyword.length>2&&k.keyCode==13){
            process_query(keyword)
        }
    })
    $("#search button").click(function(){
        process_query($("#search input").val())
    })
    function lookup_articles(keywords){
        keywords = keywords.split(" ")
        keywords = $.map(keywords,function(e){
            e = e.replace(/,/g,"")
            return e
        })
        results = []
        $.map(articles,function(article) {
            return $.ajax(
                "articles/"+article,
                {
                    success:function(response){
                        response = $("<iframe>").append($.parseHTML(response))
                        results.push([response.find("h1[data-number]").attr("data-number"),response.find("h1[data-number]").html(),keywords.filter(function(e){return response.html().search(e)!==-1}).length])
                    },
                    async:false
                }
            )
        })
        return results
    }
    const params = new Proxy(new URLSearchParams(window.location.search), {
        get: (searchParams, prop) => searchParams.get(prop),
    });
    if(params.a!==null){
        render(params.a)
    }
    $("body").on("click",".number",function(){
        navigator.clipboard.writeText(location.href+"?a="+$(this).find("span:first-of-type").html())
        $(this).after($('<span style="float:right;position:relative">').html('copied').fadeOut('slow',function(){$(this).remove()}))
    })
})